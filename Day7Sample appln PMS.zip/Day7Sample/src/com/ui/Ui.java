package com.ui;

import java.sql.SQLException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Ui {
	static Scanner scan=new Scanner(System.in);
	static EmpService empServ=null;
	
	public static void main(String f[]){
		System.out.println("Welcome, Admin!!!");
		System.out.printf("1. add product \n2. find product by id\n");
		System.out.println("3. get all products info");
		System.out.println("enter option: ");
		int choice=scan.nextInt();
		switch(choice){
		case 1:
				empServ=new EmpService();
				System.out.println("enter product info:");
				Product pdt=new Product();
				pdt.setPrice(scan.nextFloat());
				pdt.setQuantity(scan.nextInt());
				pdt.setProdId(new Random().nextInt(10909));
				pdt.setProdName(scan.next());
			int eid=0;
			try {
				eid = empServ.addProduct(pdt);
			} catch (SQLException e) {
				System.out.println("excep occurred :: "+e.getMessage());
			}
				System.out.println(eid>0?eid+" is stored successfully!!!!":"not stored");
			break;
		case 2:
			empServ=new EmpService();
			System.out.println("enter id to search ");
			Product d=null;
			try {
				d = empServ.getProductById(scan.nextInt());
			} catch (SQLException e1) {
			System.out.println("not found!! "+e1.getMessage());
			}
			System.out.println(d==null?"no data matching the id":d);
			break;
		case 3:
			empServ=new EmpService();
			List<Product> prodList=null;
			try {
				prodList = empServ.getAllProducts();
			} catch (SQLException e) {
			System.out.println(e.getMessage());
			}
			if(!prodList.isEmpty())
			prodList.stream().forEach(System.out::println);
			else{
				System.out.println("no data available!!!");
			}
			break;
		default:
			break;
			
		}
	}
}
