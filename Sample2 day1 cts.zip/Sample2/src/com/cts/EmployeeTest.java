/*header comment*/
package com.cts;
import java.lang.*;//implicitly done by compiler
//Object
//String
//System
//any related exception

public class EmployeeTest {
	private String name;//non static or instance
	private static String pass;
	
	public static void main(String[] args) {
		EmployeeTest empTest=new EmployeeTest();//object creation or instantiation
		System.out.println(empTest.name);
		System.out.println(EmployeeTest.pass);
		System.out.println(pass);
		System.out.println(empTest.name);
		}
	}
