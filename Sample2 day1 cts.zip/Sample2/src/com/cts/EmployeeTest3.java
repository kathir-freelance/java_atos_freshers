package com.cts;

public class EmployeeTest3 extends java.lang.Object  {

	public static void main(String[] args) {
		
		//className varName=new className[constructor]();
		//new --allocates the memory
		Employee e=null;//reference , default value of reference is null 
		e=new Employee();
		System.out.println(new Employee().getCompName());//anonymous object

	}

}
