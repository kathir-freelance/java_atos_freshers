package com.cts;

public class EmployeeTest2 {

	public static void main(String[] args) {
	
		Employee e1=new Employee();
		Employee e2=new Employee();
		Employee e3=new Employee(1002,"aaaa","a12345");
		//e1.Employee();
		System.out.println("id is "+e1.getEmpId());
		System.out.println("name is "+e1.getEmpName());	
		System.out.println("pass is "+e1.getPass());
		 System.out.println("company name is : "+e1.getCompName());
		System.out.println("after seting values");
		e1.setEmpId(10001);
		System.out.println("id is "+e1.getEmpId());
		e1.setEmpName("Ajay kumar");
		System.out.println("name is "+e1.getEmpName());
		e1.setPass("12345");
		System.out.println("pass is "+e1.getPass());
		e1.setCompName("CTS");
		System.out.println("company name is : "+e1.getCompName());
		
		System.out.println("---employee 2 info---");
		System.out.println("id is "+e2.getEmpId());
		System.out.println("name is "+e2.getEmpName());	
		System.out.println("pass is "+e2.getPass());
		System.out.println("company name is : "+e2.getCompName());
		
		System.out.println("---employee 3 info---");
		System.out.println("id is "+e3.getEmpId());
		e3.setEmpName("just now added");
		System.out.println("name is "+e3.getEmpName());	
		System.out.println("pass is "+e3.getPass());
		System.out.println("company name is : "+e3.getCompName());
		
	}

}
