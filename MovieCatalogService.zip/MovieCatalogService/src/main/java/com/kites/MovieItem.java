package com.kites;

public class MovieItem {

	private String movieName;
	private int movieId;
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	
	public MovieItem() {
		// TODO Auto-generated constructor stub
	}
	public MovieItem(String movieName, int movieId) {
		this.movieName = movieName;
		this.movieId = movieId;
	}
	
	
}
