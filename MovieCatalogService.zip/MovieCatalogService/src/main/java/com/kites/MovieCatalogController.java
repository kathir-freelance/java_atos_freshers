package com.kites;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/catalog")
public class MovieCatalogController {

	@RequestMapping("/{userId}")
	public List<CatalogItem> getCatalog(@PathVariable("userId") int userId){
		RestTemplate rest=new RestTemplate();
		
		List<Rating> ratings=Arrays.asList(
				new Rating("1234",4),
				new Rating("2254",3)
				);
		return ratings.stream().map(rating->
		{
		MovieItem mov=rest.getForObject("http://localhost:8082/movies/"+rating.getMovieId(), MovieItem.class);	
			return new CatalogItem(mov.getMovieName(),"test", rating.getRating());
		}).collect(Collectors.toList());
		
	}
}
