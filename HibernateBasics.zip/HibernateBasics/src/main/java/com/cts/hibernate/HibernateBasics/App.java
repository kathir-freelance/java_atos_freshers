package com.cts.hibernate.HibernateBasics;

import java.io.Serializable;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Employee;

public class App 
{
    public static void main( String[] args )
    {
    	/*Configuration configuration=new Configuration().configure();
        StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties());
        SessionFactory factory = configuration.buildSessionFactory(builder.build());
        Session session = factory.openSession();*/

    	Configuration configuration=new Configuration().configure();
    	SessionFactory sf=configuration.buildSessionFactory();
    	Session session=sf.openSession();
       	session.beginTransaction();
           	
    	Employee e=(Employee)session.get(Employee.class,1005);
    	System.out.println(e);//state- managed
    	//session.evict(e);
    	//e.setDesig("updated123");
    	//session.save(e); // constraint violation in PK
    	//session.update(e);
    	//session.flush();
   // 	session.flush();
       	//session.getTransaction().commit();
        
    	session.delete(e);
    	session.flush();
    	session.getTransaction().commit();
        //session.close();
    	
    }
}




/*	Employee emp=new Employee(1008,"larvel","Manager");
    	//BMT
    	session.beginTransaction();
    	Serializable ob=session.save(emp);//managed
    	emp.setDesig("Sr mgr");
    	//session.getTransaction().commit();
    	//emp.setDesig("Sr mgr grade 1");
    	//System.out.println(emp);//it will not store untill u in=ssue a commit
    	//session.getTransaction().commit();
    	//Exception in thread "main" org.hibernate.TransactionException: Transaction not successfully started
    	System.out.println(ob);
    	session.close();
    
 * 
 * 
 */

