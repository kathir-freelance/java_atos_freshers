package com.cts.pms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cts.pms.dao.ProductDao;
import com.cts.pms.model.Product;
@Service
public class ProductService {
	
	@Autowired
	private ProductDao pDao;
	
	public int addProduct(Product product){
		
		return pDao.addProduct(product);
	}
	
}
