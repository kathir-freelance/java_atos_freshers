package com.cts.pms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

// @Component //-- @controller , @service, @repository
@Controller
public class HomeController {
	@RequestMapping("/")
	public String getIndexPage() {
		return "index";
	}

	@RequestMapping("/home")
	public String getHome(Model model) {
		String msg = "<h1> welcome to spring home page </h1>";
		model.addAttribute("myMsg", msg); // reqeuest
		return "homepage";
	}

	@RequestMapping("/profile")
	public ModelAndView getProfilePage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("profilepage");
		String msg = "<h1> This is my profile </h1>";
		mv.addObject("myMsg", msg); // reqeuest
		return mv;
	}

	@RequestMapping("/process.do")
	public String process(@RequestParam("pName") String name, @RequestParam("qty") String quantity,
			@RequestParam("price") String price, Model model) {
		
		model.addAttribute("n",name);
		model.addAttribute("q",quantity);
		model.addAttribute("p",price);
		
		return "result";
	}
}
