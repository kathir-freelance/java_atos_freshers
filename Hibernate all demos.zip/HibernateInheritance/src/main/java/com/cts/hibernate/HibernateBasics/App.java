package com.cts.hibernate.HibernateBasics;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Account;
import com.cts.hibernate.model.DematAccount;
import com.cts.hibernate.model.SavingsAccount;

public class App {
	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		/*Account acc=new Account();
		acc.setAccNum(1001);
		acc.setName("hari");
		DematAccount demat=new DematAccount();
		demat.setAccNum(1002);
		demat.setName("vinoth");
		demat.setShares(4);
		SavingsAccount sacc=new SavingsAccount();
		sacc.setAccNum(1004);
		sacc.setInterestRate(9.7f);
		sacc.setName("lalith");
		session.beginTransaction();
		session.save(acc);
		session.save(sacc);
		session.save(demat);
		DematAccount demat1=new DematAccount();
		demat1.setAccNum(1007);
		demat1.setName("zlot");
		demat1.setShares(8);
		session.save(demat1);		
		session.getTransaction().commit();
		session.close();
		*/
		
		
		
		
		
		
	}
}



