package com.cts.hibernate.HibernateBasics;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.OrderItem;

public class App {
	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		
		Query q=session.getNamedQuery("retrieveCount");
		//q.setFetchSize(3);
	//	System.out.println(q.list());
		//refresh - changes in db will
		Query q1=session.getNamedQuery("retrieveall");
		//q1.setFirstResult(2);
		//q1.setFetchSize(2);
		System.out.println(q1.list());
		//Query q=session.createQuery("retrieveall");
		//Query q=session.createSQLQuery("retrieveall");
		//System.out.println(q.list());
		
		/*Query q=session.createSQLQuery("select * from user_detail");//native qry execution
		System.out.println(q.list());
		*/
		/*
		String hql = "from OrderItem o where o.orderId =?";
		Query q = session.createQuery(hql);
		q.setParameter(0, 5);
		List result = q.list();
		System.out.println(result);*/
		/*
		 * OrderItem order=new OrderItem(); order.setOrderId(6); String hql =
		 * "from OrderItem o where o.orderId = :orderId"; List result =
		 * session.createQuery(hql).setProperties(order).list();
		 * System.out.println(result);
		 */
		/*
		 * Query query = session.createQuery(
		 * "from OrderItem o where o.id = :id "); query.setParameter("id", 111);
		 * List<OrderItem> list=query.list(); System.out.println(list);
		 */
		/*
		 * String qry="select order.productCount FROM OrderItem order"; Query
		 * q=session.createQuery(qry); List<OrderItem> ll=q.list();//will not
		 * class cast exception System.out.println(ll);
		 */
		/*
		 * OrderItem order=new OrderItem(111,5,6,8,77,788.7f);
		 * session.beginTransaction(); session.save(order);
		 * session.getTransaction().commit();
		 */
		session.close();
	}
}
