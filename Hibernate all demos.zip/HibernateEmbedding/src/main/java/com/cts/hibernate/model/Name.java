package com.cts.hibernate.model;

import javax.persistence.Embeddable;

@Embeddable
public class Name {

	private String fName;
	private String lName;
	public String getfName() {
		return fName;
	}
	public String getlName() {
		return lName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public Name() {
		// TODO Auto-generated constructor stub
	}
	
}
