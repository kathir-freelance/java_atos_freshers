package com.cttech.HibernateDemo7.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Vehicle {

	public Vehicle() {
		// TODO Auto-generated constructor stub
	}
	@Id
	@GeneratedValue
	private int vehicleId;
	private String vehicleName;
	
	@OneToOne
	@JoinColumn(name="veh_id")
	private Engine engine;
	
	public Engine getEngine() {
		return engine;
	}
	public void setEngine(Engine engine) {
		this.engine = engine;
	}
	public int getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}
	public String getVehicleName() {
		return vehicleName;
	}
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	@Override
	public String toString() {
		return "Vehicle [vehicleId=" + vehicleId + ", vehicleName=" + vehicleName + "]";
	}
	public Vehicle( String vehicleName) {
		super();
		//this.vehicleId = vehicleId;
		this.vehicleName = vehicleName;
	}
	
	
}
