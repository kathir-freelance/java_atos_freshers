package com.cttech.HibernateDemo7.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Engine {

	private String chasisNo;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int engineNo;

	public String getChasisNo() {
		return chasisNo;
	}

	public void setChasisNo(String chasisNo) {
		this.chasisNo = chasisNo;
	}

	public int getEngineNo() {
		return engineNo;
	}

	public void setEngineNo(int engineNo) {
		this.engineNo = engineNo;
	}

	public Engine() {
		// TODO Auto-generated constructor stub
	}

	public Engine(String chasisNo, int engineNo) {
		super();
		this.chasisNo = chasisNo;
		this.engineNo = engineNo;
	}

	@Override
	public String toString() {
		return "Engine [chasisNo=" + chasisNo + ", engineNo=" + engineNo + "]";
	}

	
}
