package com.cttech.HibernateDemo7;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cttech.HibernateDemo7.entity.Vehicle;
import com.cttech.HibernateDemo7.entity.Engine;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Vehicle vehicle=new Vehicle("Mahindra");
    	Engine engine1=new Engine("cshhf6eg3yu3",922345678);
       	vehicle.setEngine(engine1);	
    	SessionFactory sessFactory=new Configuration().configure().buildSessionFactory();
    	Session session=sessFactory.openSession();
    	
    	session.beginTransaction();
    	session.save(engine1);
    	session.save(vehicle);
    	session.getTransaction().commit();
    }
}
