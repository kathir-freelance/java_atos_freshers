package com.cttech.HibernateDemo5.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class AccountUnique implements Serializable{

	private int accId;
	private String dob;
	
	
	@Override
	public String toString() {
		return "AccountUnique [accId=" + accId + ", dob=" + dob + "]";
	}


	public AccountUnique(int accId, String dob) {
		super();
		this.accId = accId;
		this.dob = dob;
	}


	public int getAccId() {
		return accId;
	}


	public void setAccId(int accId) {
		this.accId = accId;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public AccountUnique() {
		// TODO Auto-generated constructor stub
	}

}
