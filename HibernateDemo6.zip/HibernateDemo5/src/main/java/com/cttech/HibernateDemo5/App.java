package com.cttech.HibernateDemo5;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cttech.HibernateDemo5.entity.Account;
import com.cttech.HibernateDemo5.entity.AccountUnique;
import com.cttech.HibernateDemo5.entity.Address;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	AccountUnique accUnique= new AccountUnique(101,"13 may");
    	Address addr=new Address(407708,"Thane", "mumbai","marathi street");
    	Account account=new Account(accUnique,"ajay",addr);
    	   	
    	SessionFactory sessFactory=new Configuration().configure().buildSessionFactory();
    	Session session=sessFactory.openSession();
    	
    	session.beginTransaction();
    	session.save(account);
    	session.getTransaction().commit();
    }
}
