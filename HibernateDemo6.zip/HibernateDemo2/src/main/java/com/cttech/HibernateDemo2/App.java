package com.cttech.HibernateDemo2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cttech.HibernateDemo2.entity.Account;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
 
//    	Account account=new Account(1001, "aravind");
    	Account account=new Account(1002, "ajay");
    	
    //	SessionFactory sessFactory=new Configuration().configure().buildSessionFactory();	
//    	Session session=sessFactory.openSession();
//    //	Transaction trans=session.beginTransaction();
//    	//trans.begin();
//    	//session.persist(account);
//    	Serializable s=session.save(account);
//    	System.out.println(s.toString());
//    	//Serializable s1=session.save(account);
//    	//System.out.println(s1.toString());
    	
    	    
        	/*Session session=sessFactory.openSession();
        	System.out.println(session);
        	session.beginTransaction();
        	session=sessFactory.getCurrentSession();
        	System.out.println(session);
        	Serializable s=session.save(account);
    	    	//trans.commit();
    	    session.getTransaction().commit();*/
    	
    	SessionFactory sessFactory=new Configuration().configure().buildSessionFactory();
    	Session session=sessFactory.openSession();
    	session = sessFactory.getCurrentSession();
    	session.beginTransaction();
    	session.save(account);
    	session.getTransaction().commit();
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    }
}
