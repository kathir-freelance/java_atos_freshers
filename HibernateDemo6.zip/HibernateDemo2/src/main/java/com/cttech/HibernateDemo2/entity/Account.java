package com.cttech.HibernateDemo2.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Account {

	public Account() {
		// TODO Auto-generated constructor stub
	}
	@Id
	private int accountId;
	private String accName;

	public String getAccName() {
		return accName;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public Account(int accountId, String accName) {
		super();
		this.accountId = accountId;
		this.accName = accName;
	}
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accName=" + accName + "]";
	}
	
}
