package com.cttech.HibernateDemo6;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cttech.HibernateDemo6.entity.Account;
import com.cttech.HibernateDemo6.entity.Address;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Account account=new Account(1003, "ajay");
    	Address addr1=new Address(/*407708,*/"Thane", "mumbai","marathi street");
       	Address addr2=new Address(/*407709,*/"Ghansoli", "mumbai","ganpathi street");
           	
    	account.getAddrList().add(addr1);
    	account.getAddrList().add(addr2);
    	 	
    	SessionFactory sessFactory=new Configuration().configure().buildSessionFactory();
    	Session session=sessFactory.openSession();
    	
    	session.beginTransaction();
    	session.save(account);
    	session.getTransaction().commit();
    }
}
