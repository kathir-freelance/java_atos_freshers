package com.cttech.HibernateDemo6.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;

@Entity
public class Account {

	public Account() {
		// TODO Auto-generated constructor stub
	}
	@Id
	private int accountId;
	private String accName;
	
	@ElementCollection
	@JoinTable(name="account_address" ,joinColumns=@JoinColumn(name="acc_addrId"))
	private Set<Address> addrList=new HashSet<>();
	
	public Set<Address> getAddrList() {
		return addrList;
	}
	public void setAddrList(Set<Address> addrList) {
		this.addrList = addrList;
	}
	public String getAccName() {
		return accName;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public Account(int accountId, String accName) {
		super();
		this.accountId = accountId;
		this.accName = accName;
	}
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accName=" + accName + "]";
	}
	
}
