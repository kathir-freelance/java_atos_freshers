package com.cttech.HibernateDemo1;

import org.hibernate.Session;

import com.cttech.HibernateDemo1.entity.Employee;
import com.cttech.HibernateDemo1.util.HibernateUtil;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();

		// Add new Employee object
		Employee emp = new Employee();
		emp.setName("demo@mail.com");
		emp.setCity("demo");
		emp.setMobile("9898979787");
		emp.setId("1002");
		session.save(emp);
		emp.setName("ajay kumar");
		session.getTransaction().commit();
        HibernateUtil.shutdown();
	}
}
