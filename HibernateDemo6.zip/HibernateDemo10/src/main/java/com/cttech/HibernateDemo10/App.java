package com.cttech.HibernateDemo10;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cttech.HibernateDemo10.entity.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		
	//	SessionFactory sessFactory = new Configuration().configure().buildSessionFactory();
		//Session session = sessFactory.openSession();
/*//		Employee emp=(Employee)session.get(Employee.class, 1);
		//Employee emp=(Employee)session.load(Employee.class, 2);//throws exception if data not availble
		Employee emp=(Employee)session.get(Employee.class, 2);//data not in db, returns null
		System.out.println(emp);
		//session.getTransaction().commit();
		session.close();
*/
		Employee employee = new Employee("aravind");
		SessionFactory sessFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessFactory.openSession();
		session.beginTransaction();
		session.save(employee);
		employee.setEmployeeName("hari haran");
		session.getTransaction().commit();
		session.close();
		//employee.setEmployeeName("HariHaran KN");
		//above code will not stored in db until commit is given
	}
}
