package com.cttech.HibernateDemo11;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cttech.HibernateDemo11.entity.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		
		SessionFactory sessFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessFactory.openSession();
		Employee emp=(Employee)session.get(Employee.class, 1);//data not in db, returns null
		System.out.println(emp);
		session.beginTransaction();
		emp.setEmployeeName("yus");
		session.getTransaction().commit();
		session.close();
	}
}
