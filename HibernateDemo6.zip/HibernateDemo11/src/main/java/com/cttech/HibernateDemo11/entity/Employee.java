package com.cttech.HibernateDemo11.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity(name="Emp_Details")
@org.hibernate.annotations.Entity(selectBeforeUpdate=true)
public class Employee {

	@Id
	@GeneratedValue
	private int employeeId;
	private String employeeName;
	
	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + "]";
	}

	public Employee(String employeeName) {
		super();
//		this.employeeId = employeeId;
		this.employeeName = employeeName;
		
	}
	
	
}
