package com.cttech.HibernateDemo9.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Employee {

	@Id
	@GeneratedValue
	private int employeeId;
	private String employeeName;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="acc_id")
	private Set<BankAccount> accounts;

	public Set<BankAccount> getAccounts() {
		return accounts;
	}
	public void setAccounts(Set<BankAccount> accounts) {
		this.accounts = accounts;
	}
	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", account=" + accounts + "]";
	}

	public Employee(String employeeName, Set<BankAccount> accounts) {
		super();
//		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.accounts = accounts;
	}
	
	
}
