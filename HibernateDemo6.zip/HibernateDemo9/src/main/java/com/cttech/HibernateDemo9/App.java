package com.cttech.HibernateDemo9;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cttech.HibernateDemo9.entity.BankAccount;
import com.cttech.HibernateDemo9.entity.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	//String s=new String("hello1");
    	//System.out.println(s.hashCode());
    	/*BankAccount acc1=new BankAccount("Aravind");
    	BankAccount acc2=new BankAccount("Aravind");
    	BankAccount acc3=new BankAccount("Aravind");
    	Set<BankAccount> accountList=new HashSet<>();
    	accountList.add(acc1);
    	accountList.add(acc2);
    	accountList.add(acc3);
    	Employee employee=new Employee("aravind", accountList);
    	SessionFactory sessFactory=new Configuration().configure().buildSessionFactory();
    	Session session=sessFactory.openSession();
    	
    	session.beginTransaction();
    	session.save(employee);
    		 
    	session.getTransaction().commit();*/
    }
}
