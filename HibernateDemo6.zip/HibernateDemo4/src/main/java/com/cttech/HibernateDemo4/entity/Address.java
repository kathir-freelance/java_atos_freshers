package com.cttech.HibernateDemo4.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Address {

	public Address() {
		// TODO Auto-generated constructor stub
	}
	@Column(nullable=true)
	private int pin;
	@Column(name="user_city")
	private String city;
	private String state;
	private String street;
	public Address(int pin, String city, String state, String street) {
		super();
		this.pin = pin;
		this.city = city;
		this.state = state;
		this.street = street;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	
	

}
