package com.cttech.HibernateDemo4.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Account {

	public Account() {
		// TODO Auto-generated constructor stub
	}
	@Id
	private int accountId;
	private String accName;
	
	@Embedded
	@AttributeOverrides({
		@AttributeOverride(name="city",column=@Column(name="home_user_city")),
		@AttributeOverride(name="pin",column=@Column(name="home_addr_pin")),
		@AttributeOverride(name="state",column=@Column(name="home_addr_state")),
		@AttributeOverride(name="street",column=@Column(name="home_addr_street"))
	})
	private Address homeAddress;
	private Address officeAddress;
	
	public Address getHomeAddress() {
		return homeAddress;
	}
	public Address getOfficeAddress() {
		return officeAddress;
	}
	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}
	public void setOfficeAddress(Address officeAddress) {
		this.officeAddress = officeAddress;
	}
	public String getAccName() {
		return accName;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public Account(int accountId, String accName) {
		super();
		this.accountId = accountId;
		this.accName = accName;
	}
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accName=" + accName + "]";
	}
	
}
