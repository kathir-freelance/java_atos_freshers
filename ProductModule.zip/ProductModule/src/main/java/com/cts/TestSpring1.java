package com.cts;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class TestSpring1 {

	public static void main(String[] args) {
	/*	BeanFactory bf=null;
		  
		Resource res=new ClassPathResource("spring.xml");
		 bf=new XmlBeanFactory(res);*/
	//	Resource res=new FileSystemResource("outside.xml");
		ApplicationContext bf=new FileSystemXmlApplicationContext("outside.xml");
		Employee em=(Employee)bf.getBean("emp");
		System.out.println(em);
		
		//Employee em1=(Employee)bf.getBean("emp");
		//System.out.println(em1);
	}

}


