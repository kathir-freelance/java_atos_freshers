package com.ct.hibernate.persistentDemo;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.transform.Transformers;

import com.ct.hibernate.module.BankAccount;
import com.ct.hibernate.module.DematAccount;
import com.ct.hibernate.module.SavingsAccount;




public class App {
	public static SessionFactory sessionFactory;

	public static void main(String... anc) {
		Configuration configuration = new Configuration().configure();
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties()).build();
		// builds a session factory from the service registry
		sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		/*BankAccount b=new BankAccount();
		b.setId(11);
		b.setAccName("aaaa");*/
		/*DematAccount d=new DematAccount();
		d.setId(1002);
		d.setAccName("dddd");
		d.setNoofShares(54);
		SavingsAccount s=new SavingsAccount();
		s.setId(10001);
		s.setAccName("eeee");
		s.setInterestRates(10);
		//session.save(b);
		session.save(d);
		session.save(s);*/
		tx.commit();
		session.close();

	}
}
