package com.ct.hibernate.module;

import javax.persistence.Entity;

import java.io.Serializable;

import javax.persistence.*;
import javax.persistence.Table;

@Entity
public class SavingsAccount  extends BankAccount  implements Serializable
{
	 int interestRates;
	 
	 public int getInterestRates() {
		return interestRates;
	}
	 
	 public void setInterestRates(int interestRates) {
		this.interestRates = interestRates;
	}
}