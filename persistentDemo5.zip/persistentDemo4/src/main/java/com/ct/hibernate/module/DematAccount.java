package com.ct.hibernate.module;

import javax.persistence.Entity;

import java.io.Serializable;

import javax.persistence.*;
import javax.persistence.Table;

@Entity
@PrimaryKeyJoinColumn(name="myid")
public class DematAccount extends BankAccount implements Serializable
{
	 private int noofShares;
	 
	 public int getNoofShares() {
		return noofShares;
	}
	 public void setNoofShares(int noofShares) {
		this.noofShares = noofShares;
	}
}