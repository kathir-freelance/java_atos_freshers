package com.ct.hibernate.module;

import javax.persistence.Entity;

import java.io.Serializable;

import javax.persistence.*;
import javax.persistence.Table;

@Entity
public class Account implements Serializable
{
	 public Account() {
	 }
	 @Id
	 @Column(name="acc_id")
	 int accId;
	 @Column(name="acc_holder_name")
	 String accHolderName;
	 float balance;
	 String mobile;
	 @Column(name="open_balance")
	 float openingBalance;
	 public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public String getAccHolderName() {
		return accHolderName;
	}
	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public float getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(float openingBalance) {
		this.openingBalance = openingBalance;
	}
	@Override
	public String toString() {
		return "Account [accId=" + accId + ", accHolderName=" + accHolderName + ", balance=" + balance + ", mobile="
				+ mobile + ", openingBalance=" + openingBalance + "]";
	} 
	 
	 
}