package com.ct.hibernate.persistentDemo;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.transform.Transformers;

import com.ct.hibernate.module.Account;


public class App {
	public static SessionFactory sessionFactory;

	public static void main(String... anc) {
		Configuration configuration = new Configuration().configure();
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties()).build();
		// builds a session factory from the service registry
		sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		DetachedCriteria query = DetachedCriteria.forClass(Account.class);
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		//Criteria ct=session.createCriteria(Account.class);
		System.out.println(query);
		Criteria ct=query.getExecutableCriteria(session);
		//ct.add(Restrictions.ilike("accHolderName", "a%"));
		//ct.add(Restrictions.gt("openingBalance", 25000.0f));
		//ct.add(Restrictions.gt("accId",2000));
		ProjectionList p=Projections.projectionList().add(Projections.property("accHolderName"),"accHolderName").add(Projections.property("accId"),"accId").add(Projections.property("openingBalance"),"openingBalance");
		ct.setProjection(p);
		ct.addOrder(Order.asc("accId"));
		ct.addOrder(Order.desc("accHolderName"));		
		/*System.out.println(p.getProjection(0));
		System.out.println(p.getProjection(1));
		System.out.println(p.getProjection(2));*/
		ct.setResultTransformer(Transformers.aliasToBean(Account.class));
		List<Account> list=ct.list();
		System.out.println(list);
		tx.commit();
		session.close();

	}
}
