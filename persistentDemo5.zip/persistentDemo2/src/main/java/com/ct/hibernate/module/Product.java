package com.ct.hibernate.module;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


@Entity
@Table(name="Product")
@NamedQuery(name="prod",query="from Product")
public class Product {
	@Override
	public String toString() {
		return "Product [proId=" + proId + ", proName=" + proName + ", proDes=" + proDes + "]";
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
		private int proId;
		private String proName;
		private String proDes;
		
		public Product() {
			super();
			// TODO Auto-generated constructor stub
		}
		public int getProId() {
			return proId;
		}
		public void setProId(int proId) {
			this.proId = proId;
		}
		public String getProName() {
			return proName;
		}
		public void setProName(String proName) {
			this.proName = proName;
		}
		public String getProDes() {
			return proDes;
		}
		public void setProDes(String proDes) {
			this.proDes = proDes;
		}
		
}
