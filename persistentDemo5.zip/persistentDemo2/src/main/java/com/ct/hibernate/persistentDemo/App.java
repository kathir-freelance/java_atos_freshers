package com.ct.hibernate.persistentDemo;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.service.ServiceRegistry;

import com.ct.hibernate.module.Product;

public class App {
	public static SessionFactory sessionFactory;

	public static void main(String... anc) {
		Configuration configuration = new Configuration().configure();
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties()).build();
		// builds a session factory from the service registry
		sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		DetachedCriteria query = DetachedCriteria.forClass(Product.class);
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		/*
		 * Product pr=new Product(); //pr.setProId(6);//auto increment is used
		 * pr.setProName("mobile"); pr.setProDes("latest mobile features");
		 */// session.persist(pr);
			// System.out.println(session.save(pr));
			// String qry="from Product ";//hql
		// String qry="select p from Product p";//hql
		/*
		 * String qry="from Product p where p.proId=1";//hql Query qr=
		 * session.createQuery(qry); System.out.println(qr); List<Product> l=qr.list();
		 * System.out.println(l);
		 */
		// criteria and restrictions
		// below is in jpaHib
		// TypedQuery<Product> t=(TypedQuery<Product>) session.createQuery(qry);
		// Product l=t.getSingleResult();
		// System.out.println(l);

		// using SQL QUERY
		/*
		 * String qry="select * from Product";//hql SQLQuery qr=
		 * session.createSQLQuery(qry); qr.addEntity(Product.class); List<Product>
		 * l=qr.list(); System.out.println(l.get(0));
		 */
	//	String qry = "from Product p where p.proId=:pid";// hql
		/*String qry = "from Product p where p.proId=?";// hql
		
		Query qr = session.createQuery(qry);
		qr.setInteger(0, 1);
		//qr.setString(1,"1");
	//	qr.setParameter("pid",1);
		System.out.println(qr);
		List<Product> l = qr.list();
		System.out.println(l);*/
		
		//use criteria
		//String qry = "from Product p where p.proId=?";
		//Query qr = session.createQuery(qry);
		/*Criteria crit = session.createCriteria(Product.class);
		List<Product> results = crit.list();
		System.out.println(results);
		*/
	/*	Criteria crit = session.createCriteria(Product.class);
		crit.add(Restrictions.eq("proDes","latest"));
		crit.add(Restrictions.eq("proName","calculator14"));
		List<Product> results = crit.list();
		System.out.println(results);*/
	/*	Criteria crit = session.createCriteria(Product.class);
		crit.add(Restrictions.like("proName","mo%",MatchMode.EXACT));
		List<Product> results = crit.list();
		System.out.println(results);
		*/
		//detached query
		/*List results = query.getExecutableCriteria(session).setMaxResults(3).list();
		System.out.println(results);	*/	
		
		/*String qry="select * from Product";//hql 
		Query qr=session.createSQLQuery(qry); 
		qr.setFirstResult(2);
		qr.setMaxResults(2);
		List<Product> l=qr.list(); 
		System.out.println(l);*/
	/*	Criteria crit = session.createCriteria(Product.class);
		Criterion price = Restrictions.eq("proDes","casio14");
		crit.setResultTransformer( DistinctRootEntityResultTransformer.INSTANCE);
		List<Product> results = crit.list();
		System.out.println(results);*/
	
		/*Query qr=session.getNamedQuery("prod");
		Criteria cr=session.createCriteria("prod");
		
		List<Product> results = qr.list();
		System.out.println(results);*/
		
		tx.commit();
		session.close();

	}
}
