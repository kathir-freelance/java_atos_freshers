package com.hibernate.HibDemo1_p1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		/*Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory =new Configuration().configure().buildSessionFactory();
		*/
		SessionFactory factory = HibernateUtil.getSessionFactory();
		//Session session = factory.openSession();
		//Product p = new Product();

	}
}
