package com.ct.hibernate.module;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.*;

@Entity
@Inheritance(strategy=InheritanceType.JOINED)
//@DiscriminatorColumn(name="accType",discriminatorType=DiscriminatorType.STRING)
public class BankAccount implements Serializable
{
	 @Id
	 private int id;
	 private String accName;
	 private BankDetails bd;
	 
	 @Embedded
	 public BankDetails getBd() {
		return bd;
	}
	 public void setBd(BankDetails bd) {
		this.bd = bd;
	}
	 public int getId() {
		return id;
	}
	 public void setId(int id) {
		this.id = id;
	}
	 
	 public void setAccName(String accName) {
		this.accName = accName;
	}
	 public String getAccName() {
		return accName;
	}
}