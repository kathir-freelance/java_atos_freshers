package com.ct.hibernate.module;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
@Embeddable
public class BankDetails {
	//@Id
	private int detailId;
	private String branchName;
	public String getBranchName() {
		return branchName;
	}
	public int getDetailId() {
		return detailId;
	}
	public void setDetailId(int detailId) {
		this.detailId = detailId;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
}
