package com.atos;

import java.util.Scanner;

public class UserDefined {

	public static void main(String[] args) {
		//amt  =1000
		//existing bal in acc is 500
		//min bal to be maintained 500
			int myBalance=500;
		try {
			new UserDefined().withdraw();
		} catch (MoneyLessException e) {
			System.out.println(e.getMessage());
		}	}
	public void withdraw() throws MoneyLessException{
		Scanner scan=new Scanner(System.in);
		int amt =scan.nextInt();
		int minBal=500;
		if(amt >minBal){
			throw new MoneyLessException("amt cannot be withdrawn , no sufficient bal avbl");
		}
		else{
			System.out.println("pls take the cash");
		}	}}
//is created by the devleoper for his own logic or criteria
// size 5 u try assign a[6] aiobe
//obj is null, u call met using it - npe
//file s missing - fnfe
class MoneyLessException extends Exception{
	public MoneyLessException() {
		// TODO Auto-generated constructor stub
	}
	public MoneyLessException(String msg) {
		super(msg);
	}
	
}


