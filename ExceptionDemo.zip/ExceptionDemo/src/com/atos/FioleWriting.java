package com.atos;

import java.io.FileWriter;
import java.io.IOException;

public class FioleWriting {

	public static void main(String[] args) {
	
		FileWriter fr=null;
		try{
		fr=new FileWriter("a.txt"); // W+
		fr.write("hi");//prob 
		}
		catch(IOException e){}
		finally{
			if(fr!=null){
				try {
					fr.close();
				} catch (IOException e) {
					System.out.println("unable to close thee resource");
				}
			}
			
		}
	}

}
