package com.atos;

import java.io.FileWriter;
import java.io.IOException;
class B implements AutoCloseable{
	
	public B() {
	System.out.println("obj b is craeted");
	}
	
	@Override
	public void close() throws Exception {
	System.out.println("obj b is closed");	
	}
}
class A  implements java.lang.AutoCloseable
{

	public A() {
	
		System.out.println("obj A is craeted");
		}
	@Override
	public void close() throws Exception {
		throw new Exception();
		//System.out.println("obj a is closed");
		
	}
	
}
public class FileTryRes {

	public static void main(String[] args) {
	//class shud im[pplement a interface called as autoCloseable or Closeble interface
		try(B o=new B();A ob=new A(); FileWriter fr=new FileWriter("a.txt"))
		{
		 System.out.println("in try blok");
		fr.write("hi");//prob 
		}
		catch(Exception e){
			System.out.println("in catch");
		}
	
	}

}
