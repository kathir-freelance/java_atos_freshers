package com.atos;

public class ArrayExcep {

	int a=0;int b=0;
	
	public static void main(String ar[]){
		
		/*int a[]=new int [5];//0 1 2 3 4
		a[5]=900;
	//	System.out.println(a[5]);
		
		String s=null;
		System.out.println(s.length());*/
		try{
		int res=new ArrayExcep().getValue_Add_Square();
		res=(res*1000+30);
		System.out.println(res);
		}
		catch(Exception e){
			System.out.println("prob occured :: "+ e.getMessage());
			
		}
		finally{
			System.out.println("in finally");
		}
		
	}
	int getValue_Add_Square() throws Exception
	{
		//scanner
		a=9; b=8;
		int c=a+b;
		return findSquare(c);
	}
	private int findSquare(int c)throws Exception{
		int fr=0;
	//	if(fr==0)
	//	throw new Exception("exception since fr s 0");
	//	try{
	/*	Scanner scan=new Scanner(System.in);
		int userInp= scan.nextInt();
		 fr=((int) Math.sqrt(c)/userInp);*/
		//}
		/*catch(Exception e){
			
			System.out.println("prob occured "+e.getMessage());
		}*/
		return fr;
	}
	
	
}
