package com.atos;

import java.util.InputMismatchException;

public class Excep1 {

	public static void main(String[] args) {
	
		int a=9;
		int b=3;
		int res=0;
		try{
		res=a/b;   //throw  new ArthmeticExcep();
		System.out.println(res);
		Excep1 e=null;
		e.toString();//npe
		}
		catch(ArithmeticException ae){
			System.out.println(ae.getMessage());
		}
		catch(NullPointerException npe){
			System.out.println("obj is null");
		}
	catch(ArrayIndexOutOfBoundsException| InputMismatchException com){
		System.out.println("aiobe occured or input mismatch");	
		}
		
		catch(Exception e){
		/*	ae.printStackTrace();*/
			System.out.println(e);
			System.out.println("prob occured :: "+e.getMessage());
		}
	
		System.out.println("normal flow of the program");
	}

}
