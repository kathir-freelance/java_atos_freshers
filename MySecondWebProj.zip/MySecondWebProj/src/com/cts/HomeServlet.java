package com.cts;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HomeServlet")
public class HomeServlet extends HttpServlet {
	PrintWriter out = null;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		out = resp.getWriter();		
		out.println(
				"<form action='process'>Enter Number : <input type='text' name='numb' placeholder='enter a number'/><input type='submit' value='check'/></form>");
		String succ=(String)req.getAttribute("mySuccMsg");
		String err=(String)req.getAttribute("myErrMsg");
		out.println(succ!=null?succ:"");
		out.println(err!=null?err:"");
	}

}


