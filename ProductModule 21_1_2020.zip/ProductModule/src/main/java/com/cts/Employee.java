package com.cts;

public class Employee {

	public Employee() {
	System.out.println("i am called");
	}
}
