package com.cts.pms.ProductModule_3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.pms.ProductModule_3.model.Car;

public class App {
	public static void main(String[] args) {
		ApplicationContext bf = null;
		bf = new ClassPathXmlApplicationContext("spring.xml");
		Car c1 = (Car) bf.getBean("carObj");
		System.out.println(c1);
		System.out.println(c1.getEngine());
		
	}
}
