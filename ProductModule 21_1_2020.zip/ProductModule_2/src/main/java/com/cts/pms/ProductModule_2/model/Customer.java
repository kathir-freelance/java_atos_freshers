package com.cts.pms.ProductModule_2.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Scope(value = "prototype")
@Component("cust")
public class Customer {
	public Customer() {
		System.out.println("in cust constr");
	}
}
