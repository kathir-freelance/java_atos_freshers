package com.cts.pms.ProductModule_2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.pms.ProductModule_2.model.Customer;
import com.cts.pms.ProductModule_2.model.Product;

public class App {
	public static void main(String[] args) {
		ApplicationContext bf = null;
		bf = new ClassPathXmlApplicationContext("spring.xml");
		/*Product em = (Product) bf.getBean("prod");
		System.out.println(em);
		Product em1 = (Product) bf.getBean("prod");
		System.out.println(em1);*/
		Customer c1 = (Customer) bf.getBean("cust");
		System.out.println(c1);
		Customer c2= (Customer) bf.getBean("cust");
		System.out.println(c2);
	}
}
