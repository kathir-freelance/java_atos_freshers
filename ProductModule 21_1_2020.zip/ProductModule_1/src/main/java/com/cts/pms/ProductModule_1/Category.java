package com.cts.pms.ProductModule_1;

public class Category {
public Category() {
System.out.println("in constr - category");

}
}
