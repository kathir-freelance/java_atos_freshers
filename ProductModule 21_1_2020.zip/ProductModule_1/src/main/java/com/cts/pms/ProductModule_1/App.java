package com.cts.pms.ProductModule_1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext bf=null;
    	bf=new ClassPathXmlApplicationContext("spring2.xml");
    	Product em=(Product)bf.getBean("product");
    	System.out.println(em);
		System.out.println(em.getCategoryObj());
		
	   }
}
