package com.cts.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet5
 */
@WebServlet("/s5")
public class Servlet5 extends HttpServlet {
	PrintWriter out = null;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		out = resp.getWriter();
		out.println("<html><head><title>Page</title></head>");
		out.println("<body>");
		out.println(
				"<form action='process.do' method='GET'>Name :<input type='text' name='name'/><br/> 		city: <input type='text' name='city'/><br/>	mobile: <input type='text' name='mobile'/><br/>		<input type='submit' value='store'/><br/>	</form>");
		out.println("</body>");
		out.println("</html>");
		out.println("<a href='s1'>link to servlet 1</a>");
	}

}