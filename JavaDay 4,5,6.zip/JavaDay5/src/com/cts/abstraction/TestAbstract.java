/*package com.cts.abstraction;

public class TestAbstract {

	public static void main(String[] args) {
		A ob=new A();
		  
	}

}
abstract class A
{
	public void getData(){}
		
	public abstract void display();
	public abstract void delete();
}

class B extends A{

	public void display(){}
	public void delete(){}

}


*/