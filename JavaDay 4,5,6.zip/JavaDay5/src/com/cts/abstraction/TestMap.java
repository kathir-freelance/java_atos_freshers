package com.cts.abstraction;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class TestMap {

	public static void main(String[] args) {
		Map<Integer,String> m=new HashMap();//hashCode() and equals()
		m.put(1, "one");
		m.put(1, "one");
		m.put(1, "different");
		/*m.put('b', 2);
		m.put('c', 2);
		m.put(null, 2);
		m.put(null, 6);
		m.put("3","three");
		m.put(4.0f,new Integer(4));*/
		System.out.println(m);
		Set keys=m.keySet();
		System.out.println(keys);
		Collection c=m.values();
		System.out.println(c);
		Set ent=m.entrySet();
		System.out.println(ent);
		//Map.Entry
		
	}

}
