package com.cts.abstraction;

public class Institute {

}
