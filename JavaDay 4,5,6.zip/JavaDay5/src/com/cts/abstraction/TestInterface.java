package com.cts.abstraction;

public class TestInterface {

	public static void main(String[] args) {
		//create reference of base type
		IContract2 i=null;
		i=new TrainingInstitute();
		i.trainJava();
		i.trainJ2ee();
		i.trainSpring();
		/*IContract2 i2=null;
		i2=new TrainingInstitute();
		i2.trainSpring();*/
		
		
		
		
	}

}
