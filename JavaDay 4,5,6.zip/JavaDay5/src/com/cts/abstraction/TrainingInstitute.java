package com.cts.abstraction;

public class TrainingInstitute implements IContract2{ // implements IContract,IContract2{
	private int balanceDays=1;
	
	@Override
	public void trainJava() {
		System.out.println("training in java got over");
		balanceDays=IContract.No_OF_Days-15;
		System.out.println("balance days "+balanceDays);
	}
	@Override
	public void trainJ2ee() {
		System.out.println("training in j2ee got over");
		balanceDays=balanceDays-16;
		System.out.println("balance days "+balanceDays);
	}
	@Override
	public void trainSpring() {
		System.out.println("training in Spring got over");
		balanceDays=IContract2.No_Days-10;
		System.out.println("balance days "+balanceDays);
	
	}

	
}
