package com.cts.abstraction;

public class Primate {

		public void jump()
		{
		System.out.println("jumping");
		}
		public void walk()
		{
		System.out.println("uses 2 legs and 2 hands ");
		}
		
}
