package com.cts.abstraction;

public interface IContract2 extends IContract///prefix by I for interfaces
{
	public static final int No_Days=10;
	public abstract void trainSpring();
}
