package com.cts.abstraction;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Excep1 {

	public static void main(String[] args) {
		try{
		Scanner scan=new Scanner(System.in);
		System.out.println("enter num 1");
		int a=scan.nextInt();
		System.out.println("enter num 2");
		int b=scan.nextInt();
		int c=0;
		//tc, tcf, tf,tcccf,tcccc
		//try with resources
		c=a/b;
		System.out.println("result is "+c);
		}
		catch(InputMismatchException e){
			System.out.println("pls enter correct input:: "+e.getMessage());
		}
		/*catch(NullPointerException e){
			System.out.println("initialize the obj :: "+e.getMessage());
		}*/
		catch(NullPointerException | ArithmeticException e){
			System.out.println("pls dont divide by zero :: "+e.getMessage());
		}
		catch(Exception e){
			System.out.println("exception "+e.getMessage());
		}
		
		finally{
			System.out.println("in finally");
		}
		
		
		
	}

}
