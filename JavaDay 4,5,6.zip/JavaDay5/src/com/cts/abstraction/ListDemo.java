package com.cts.abstraction;

import java.util.*;

public class ListDemo {

	public static void main(String[] args) {
		List l=new ArrayList();
		//Set l=new HashSet();
		l.add(5+5+"hi"+5);
		l.add(10);// new Integer(10);// auto boxing
		l.add(10);
		l.add("hello");
		l.add('A');
		l.add(10.5f);
		l.add("hello");
		l.add(new Integer(9887)); //boxing
		System.out.println("data of list "+l);//auto-unboxing
		System.out.println("in position 3 data is ? "+l.get(2));
		System.out.println("in position 6 data is ? "+l.get(5));
		l.add(2,"element added");
		System.out.println("new data added "+l);
		l.set(5,'a'); // replacing data in a  particular index
		System.out.println("new modification  "+l);
		System.out.println(l.size());
		l.remove(6);
		System.out.println("after removing index 8 value "+l);
		System.out.println(l.contains(987));
		l.clear();
		System.out.println("after clear() - "+l);
		System.out.println("is list empty? - "+l.isEmpty());
		
		//9 wrapper classes - equivalent class types of the primitives
		//8 are the primitives equivalent
		//Void wrapper class
		
		/*Integer i=90; //autoboxing
		int a=890;
		Integer i1=new Integer(a);//boxing
		
		int h=i1.intValue();//unboxing
		System.out.println(h);
		System.out.println(i1);//auto-unboxing
	*/}

}












