package com.cts.abstraction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class TestList2 {

	//generics - template 
	
	public static void main(String[] args) {
		Employee emp1=new Employee(111,"kumar","CEO","AAA");
		Employee emp2=new Employee(1001,"ajay","Admin","CTS");
		Admin ad=new Admin();
		Manager m=new Manager();
		Primate p1=new Primate();
		Primate p2=new Primate();
		
	//	List<Employee> l=new ArrayList();
	//	List<Employee> l=new ArrayList<Employee>();
		List<Employee> l=new ArrayList<>();//j7
		l.add(emp1);
		l.add(emp2);
		l.add(m);
		l.add(ad);
		
	//	l.add(p1);
	//	l.add(p2);
		System.out.println(l);
		
	}

}
