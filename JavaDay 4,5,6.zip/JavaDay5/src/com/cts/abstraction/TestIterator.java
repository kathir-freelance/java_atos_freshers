package com.cts.abstraction;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class TestIterator {

	public static void main(String[] args) {
		List l=Arrays.asList(10,20,30,40);//size fixed 
		//l.add(9293);//unsupported operation
		System.out.println(l);
		for(Object h:l){
			Integer i=(Integer)h;
			System.out.println(i);
		}
		Iterator it=l.iterator();
		while(it.hasNext()){
			it.remove();
			System.out.println(it.next());
		}
		System.out.println(l);
		
		
		
		
		
		
	}

}
