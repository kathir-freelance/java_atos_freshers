package com.cts.abstraction;

public interface IContract ///prefix by I for interfaces
{
	public static final int No_OF_Days=31;
	public abstract void trainJava();
	public abstract void trainJ2ee();
}
