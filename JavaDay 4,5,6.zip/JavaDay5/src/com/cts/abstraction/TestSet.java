package com.cts.abstraction;

import java.util.*;

public class TestSet {

	public static void main(String[] args) {
		Set<String> s=new TreeSet();
		s.add("hello");
		s.add("hello");
		s.add("ansi");
		s.add("Ansi");
		s.add("charset");
		s.add("boxing");
		s.add("yaml");
		s.add("git");
		//s.add(null);//till java6 allowed null to be added 
		//from j7 it throws NPE
		System.out.println(s);
		
		Set ss=new LinkedHashSet();
		//ordered(insertion order, will not allow duplic)
		ss.add("hello");
		ss.add("welcome");
		ss.add("welcome");
		ss.add(100);
		ss.add(100);
		ss.add(150);
		ss.add(100.8);
		ss.add('A');
		System.out.println(ss);
		
	}

}
