package com.cts.polymorphism;

public class Car implements Flyer{

	@Override
	public void fly() {
		System.out.println("car - flys");
	}

}
