package com.cts.polymorphism;
public interface Flyer{
	int a=90;//mandate
	public abstract void fly();
	/*public static void display()
	{
	}
	public default void getData()
	{
	}*/
}