package com.cts.polymorphism;

public class Bus implements Flyer {

	@Override
	public void fly() {
		System.out.println("bus - flys");		
	}

}
