package com.cts.polymorphism;

public class TestInterface{

	public static void main(String[] args) {
	
		Flyer f=null;//new Flyer();
		
	}

}
