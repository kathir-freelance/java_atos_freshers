package com.cts.polymorphism;

public class Manager extends Employee 
{
	public void work(){
		System.out.println("Manager - works");
	}
	public void manageProjects(){
		System.out.println("projects");
	}
	

}
