package com.cts.polymorphism;

public class TestPoly1{

	public static void main(String[] args) {
		Employee employee=null; //reference variable
		//employee.work();//throws NPE
		employee=new Employee();//points to its own object
		employee.work();
		
		//dynamic poly
		employee=new Admin();//upward casting
	//	employee=new Manager();
		//employee.manageInventory();
		if(employee instanceof Admin){
		employee.work();
		Admin ad=(Admin)employee;//down ward casting
		ad.manageInventory();//its possible , its converted gto admin
		}
		else{
		//at same time someone chooses manager
		employee.work();
		Manager mn=(Manager)employee;
		mn.manageProjects();
		}
		System.out.println(employee instanceof Employee);
		System.out.println(employee instanceof Object);
	}

}
