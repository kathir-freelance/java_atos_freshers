package com.cts.polymorphism;

public class Admin extends Employee
{
	public void work(){
		System.out.println("Admin - work");
	}
	public void manageInventory(){
		System.out.println("purchases inventory items");
	}

}
