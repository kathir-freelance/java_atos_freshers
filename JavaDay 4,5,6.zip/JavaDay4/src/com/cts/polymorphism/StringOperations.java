package com.cts.polymorphism;

public class StringOperations{

	public static void main(String[] args) {
		
		//public final class java.lang.String 
		
		//String s="hello"; //literal
		//String s1=new String(""); //String Object
		
		// indexOf,charAt,substring,subSequence,value()
		//trim(), upper,lower,replaceAll(),split
		//toCharArray, equals,toString,intern
		
		String s="hello";
		String s1="HELLO WORLD";
		System.out.println(s1.length());
		//System.out.println(s1.equals(s)); //check content
		//System.out.println(s1==s); //check reference
		System.out.println("upper "+s.toUpperCase());
		System.out.println("lower "+s1.toLowerCase());
		//s1=s1.concat("welcome");//re-initialization
		//System.out.println(s);
		//System.out.println(s1);
	//	s1=s+s1;
		//System.out.println(s1);
		
		System.out.println("indexOf : "+s1.indexOf('W'));
		System.out.println("indexOf : "+s1.indexOf("WORLD"));
		System.out.println("Lst index :"+s1.lastIndexOf("L"));
		System.out.println("charAt : "+s1.charAt(4));
		
		String s2="   da  te   ";
		System.out.println("--"+s2+"--");
		System.out.println("--"+s2.trim()+"--");
		
		System.out.println(s1.substring(4,6));
		//subsequence
		
		String grades="ABCDE";
		char ch[]=grades.toCharArray();
		/*for(int i=0;i<ch.length;i++)
		{
			System.out.println(ch[i]);
		}*/
		//Enhanced for loop
		/*for(dest:src){
			//src- can hold multiples values
			//array, collections
			 //char[] - dest char
			  //int[] - dest int
			   //employee[] - dest Employee class
			   //cannot do decrementation 
		}*/
		for(char d:ch)
		{
			System.out.println(d);
		}
		
		String days="mon-tue-wed-thur";
		String dd[]= days.split("-");
		for(String h:dd){
			System.out.println(h);
		}
		
		String data="encrypter";
		System.out.println(data.getBytes());
		
		System.out.println(data.replace('r', 'R'));
		
		System.out.println(data.replace("er", "ER"));
		//replaceALL
		//matches
		//intern()
		System.out.println(" ".isEmpty());
		
		
	}

}








