package com.cts.excep;

//Checked exception
public class MoneyLessException extends Exception {

	public MoneyLessException() {
		// TODO Auto-generated constructor stub
	}
	public MoneyLessException(String msg) {
		super(msg);
	}
	
}
