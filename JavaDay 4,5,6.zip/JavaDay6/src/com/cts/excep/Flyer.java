package com.cts.excep;

//Runnable- run()

@FunctionalInterface //j8
public interface Flyer {
	public abstract void fly();
//	public abstract void fly1();
	//we can have static & default in func interface
	public static void m(){}
	public default void m1(){}
	
}
