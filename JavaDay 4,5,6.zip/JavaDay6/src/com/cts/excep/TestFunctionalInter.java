package com.cts.excep;

public class TestFunctionalInter {

	public static void main(String[] args) {
		StringProducer sp=null;
		sp=(name)->{String data="Mr.";
						data=data+name;
						data=data+", Welcome!!!";
						return data;
				};
		String h=sp.produce("Kumar");
		System.out.println(h);
	}

}
