package com.cts.excep;

public interface StringProducer {
	//public abstract String produce();
	public abstract String produce(String name);
}
