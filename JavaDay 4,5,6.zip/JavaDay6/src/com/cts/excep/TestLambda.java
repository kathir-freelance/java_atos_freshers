package com.cts.excep;

import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Supplier;

public class TestLambda {

	public static void main(String[] args) {
		Supplier<Empl> empSupp=()->new Empl();
		Empl obj1=empSupp.get();
		System.out.println(obj1);
		Empl obj2=empSupp.get();
		System.out.println(obj2);
		
		BiPredicate<Integer,Integer> ob=(Integer t, Integer u)->t>u?true:false;
		boolean b=ob.test(10, 20);
		System.out.println(b);
		Function<Empl,Admin> oo=(emp)->new Admin();
		Admin ad=oo.apply(new Empl());
		System.out.println(ad);
	}

}
class Empl{}
class Admin{}
/*class EmpSupp implements Supplier<Empl>{

	@Override
	public Empl get() {
		// TODO Auto-generated method stub
		return new Empl();
	}
	
}*/
/*class S implements BiPredicate<Integer, Integer>{
	@Override
	public boolean test(Integer t, Integer u) {
		// TODO Auto-generated method stub
		return false;
	}
}*/

class F implements Function<Empl,Admin>{
	
	@Override
	public Admin apply(Empl t) {
		return new Admin();
	}
}
