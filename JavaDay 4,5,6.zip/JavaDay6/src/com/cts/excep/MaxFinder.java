package com.cts.excep;

@FunctionalInterface
public interface MaxFinder {
	public abstract int max(int num1,int num2);
//	public abstract int max1(int num1,int num2);
}

/*class Arith implements MaxFinder{

	@Override
	public int max(int num1, int num2) {
		return num1>num2?num1:num2;
	}
	
}*/