package com.cts.excep;

import java.util.Scanner;

public class TestThrows {
	//	jvm /system 
	public static void main(String[] args){// throws MoneyLessException {
		Scanner scan=new Scanner(System.in);//open
		System.out.println("enter the amount: ");
		int amount=scan.nextInt();
		if(amount<500){
			try {
			//	throw new NullPointerException("null value");
				throw new MoneyLessException("money should be greater than 500");
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		else{
			System.out.println("done!!!");
		}
		scan.close();		
	}

}
