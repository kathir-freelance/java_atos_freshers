package com.cts.excep;

public class TestUserDefined {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
