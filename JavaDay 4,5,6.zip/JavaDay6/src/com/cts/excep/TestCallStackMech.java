package com.cts.excep;

import java.sql.SQLException;

public class TestCallStackMech {
	public void withdraw() throws ClassNotFoundException {
		updateMyAcc();
		System.out.println("withdrawn");
	}

	public void updateMyAcc() throws ClassNotFoundException {
		creditClient();
		System.out.println("ur account - updated");
	}

	public void creditClient()throws ClassNotFoundException{
		updateLog();
		System.out.println("credited & updated client");		
		throw new ClassNotFoundException();
	}

	public void updateLog()
	{
		System.out.println("logged the information");
	}
	public static void main(String[] args) {
		//call stack mechnism - LIFO
		//any exception happens in any called method has to be 
		//reported back only to the caller
		try {
			new TestCallStackMech().withdraw();
		} catch (ClassNotFoundException e) {
			System.out.println("class not found - add jar"+e.getMessage());
		}
		// excep happens at 
		// any level of stack and 
		//called method can be in any layer too
		

	}

}
