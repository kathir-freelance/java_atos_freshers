package com.cts.excep;

public class TestFunctionalInter2 {

	public static void main(String[] args) {
		MaxFinder mx=null;
		/*mx=new Arith();
		int res=mx.max(10,23);
		System.out.println(res);*/
		//mx=(int num1,int num2)->num1>num2?num1:num2;
		mx=(num1,num2)->num1>num2?num1:num2;
		int res=mx.max(10,23);
		System.out.println(res);
		
		//where {} is used in lambda
	/*	mx=(int num1,int num2)->{
				int res=num1>num2?num1:num2;
				return res;
				};*/
		
	}

}
