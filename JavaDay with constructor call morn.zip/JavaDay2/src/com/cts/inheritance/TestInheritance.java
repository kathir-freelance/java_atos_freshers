package com.cts.inheritance;

public class TestInheritance {

	public static void main(String[] args) {
		ScientificCalculator obj=new ScientificCalculator();
		obj.add(4,3);
		obj.sub(5,6);
		obj.cos();
		obj.sin();
		//Calculator calc=new Calculator();
		//calc.add();
		//calc.sub();
		//calc.sin();
		//calc.cos();
	}

}
