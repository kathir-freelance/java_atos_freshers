package com.cts.inheritance;

public class ProgrammingCalculator extends Calculator
{

}
