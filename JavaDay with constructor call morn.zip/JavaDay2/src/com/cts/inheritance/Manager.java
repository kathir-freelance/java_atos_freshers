package com.cts.inheritance;

public class Manager extends Employee {

}
