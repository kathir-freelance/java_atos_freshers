package com.cts.inheritance;

public class TestInher3 {

	public static void main(String[] args) {
		
		Admin ad=new Admin(1001,"Ajay","Admin","CTS");
		
	}

}
