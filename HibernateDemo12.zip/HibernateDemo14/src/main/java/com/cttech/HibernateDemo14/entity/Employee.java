package com.cttech.HibernateDemo14.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

@NamedQueries({
	//@NamedQuery(name="findByName",query="from Emp_data  where employeeName=:name")
	@NamedQuery(name="findByName",query="select e.employeeId,e.employeeSalary from Emp_data e where employeeName=:name")
})
@Entity(name="Emp_data")
public class Employee {

	@Id
	@GeneratedValue
	private int employeeId;
	private String employeeName;
	private int employeeSalary;
	
	
	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
				+ employeeSalary + "]";
	}

	public int getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public Employee(String employeeName, int employeeSalary) {
		super();
	//	this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}
	

	
}
