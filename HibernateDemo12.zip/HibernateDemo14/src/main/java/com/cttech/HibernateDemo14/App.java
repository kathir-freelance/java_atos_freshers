package com.cttech.HibernateDemo14;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cttech.HibernateDemo14.entity.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
	
	/*	Employee employee1 = new Employee("aravind",30000);
		Employee employee2 = new Employee("rahul",50000);
		Employee employee3 = new Employee("hari",60000);
		Employee employee4 = new Employee("lokesh",56000);
		Employee employee5 = new Employee("ragu",79000);
		Employee employee6 = new Employee("anuj",80000);*/
		SessionFactory sessFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessFactory.openSession();
//		session.beginTransaction();
//		session.save(employee1);session.save(employee3);session.save(employee5);
//		session.save(employee2);session.save(employee4);session.save(employee6);
//		session.getTransaction().commit();
		Query qry= session.getNamedQuery("findByName");
		qry.setParameter("name","rahul");
		List<Employee> employees=qry.list();
		Iterator it = employees.iterator();
		while(it.hasNext())
		{
		   Object[] o = (Object[])it.next();
		   System.out.println("-------"+o[1]);
		
		}
	}
}
