package com.cttech.HibernateDemo14.entity;

import javax.persistence.Id;

import org.hibernate.annotations.Entity;

@Entity
public class Sample {
	
	@Id
	int id;

}
