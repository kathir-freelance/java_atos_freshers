package com.cttech.HibernateDemo17;

import java.util.Iterator;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cttech.HibernateDemo17.entity.Employee;

public class App {
	public static void main(String[] args) {
	
/*			Employee employee1 = new Employee("aravind",30000);
		Employee employee2 = new Employee("rahul",50000);
		Employee employee3 = new Employee("hari",60000);
		Employee employee4 = new Employee("lokesh",56000);
		Employee employee5 = new Employee("ragu",79000);
		Employee employee6 = new Employee("anuj",80000);
*/		
		SessionFactory sessFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessFactory.openSession();
	
		Query qry=session.createQuery("from Employee_Details where employeeId=1");
		qry.setCacheable(true);
		List li=qry.list();
		session.close();
		
		
		Session session1 = sessFactory.openSession();
		Query qry1=session1.createQuery("from Employee_Details where employeeId=1");
		qry1.setCacheable(true);
		List list=qry1.list();	
		session1.close();//same qry executed for 2 times as prev session was closed and cache got cleared
		//session is first level cache
		
		
	}
}
