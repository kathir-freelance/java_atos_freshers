package com.cttech.HibernateDemo13;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.cttech.HibernateDemo13.entity.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
	
		Employee employee = new Employee("aravind");
		SessionFactory sessFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessFactory.openSession();
		
		//name is case sensitive as given in @entity -in entity class
		//Query qry=session.createQuery("from Emp_Details");
//		Query query=session.createQuery("from Emp_Details where id>2");
//		query.setFirstResult(2);  
//		query.setMaxResults(4);  
//		List<Employee> list=query.list();
//		System.out.println(list);
		/*
		session.beginTransaction();
		Query q=session.createQuery("update Emp_Details set employeename=:n where employeeId=:i");  
		q.setParameter("n","Udit Kumar");  
		q.setParameter("i",5);  
		  
		int status=q.executeUpdate();  
		System.out.println(status);  
		session.getTransaction().commit();*/

		/*session.beginTransaction();
		Query query=session.createQuery("delete from Emp_Details where employeeid=:n");    
		query.setParameter("n",6);  
		
		int status=query.executeUpdate();  
		System.out.println(status);  
		session.getTransaction().commit();
		*/
	/*	session.beginTransaction();
		Query q=session.createQuery("select count(employeeid) from Emp_Details");
		
		System.out.println(q.list().get(0));  
		session.getTransaction().commit();*/
		
		//HCQL - Criteria
/*		Criteria c=session.createCriteria(Employee.class);//passing Class class argument  
		List list=c.list();  
		System.out.println(list);
*/		
		/*Criteria c=session.createCriteria(Employee.class);
		List list=c.add(Restrictions.gt("employeeId", 3)).list();
		System.out.println(list);*/
		Criteria c=session.createCriteria(Employee.class);
		c.add(Restrictions.ge("employeeId", 2)).addOrder(Order.desc("employeeName"));  
		List list=c.list();  
		System.out.println(list);

	}
}
