package com.cttech.HibernateDemo16;

import java.util.Iterator;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cttech.HibernateDemo16.entity.Employee;

public class App {
	public static void main(String[] args) {
	
/*			Employee employee1 = new Employee("aravind",30000);
		Employee employee2 = new Employee("rahul",50000);
		Employee employee3 = new Employee("hari",60000);
		Employee employee4 = new Employee("lokesh",56000);
		Employee employee5 = new Employee("ragu",79000);
		Employee employee6 = new Employee("anuj",80000);
*/		
		SessionFactory sessFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessFactory.openSession();
		/*session.beginTransaction();
		session.save(employee1);session.save(employee3);session.save(employee5);
		session.save(employee2);session.save(employee4);session.save(employee6);
		*/
		/*
		Employee emp=(Employee)session.get(Employee.class, 1);
		Employee emp1=(Employee)session.get(Employee.class, 1);*/
		//in above case only once the query gets executed
		//session.getTransaction().commit();

		//Employee emp=(Employee)session.get(Employee.class, 1);
		//Employee emp1=(Employee)session.get(Employee.class, 2);
		//twice the select runs
		session.beginTransaction();
		Employee emp=(Employee)session.get(Employee.class, 1);
		emp.setEmployeeSalary(30000);
		session.getTransaction().commit();
		session.close();
		
		
		Session session1 = sessFactory.openSession();
		session1.beginTransaction();
		Employee emp2=(Employee)session1.get(Employee.class, 1);
		
		emp2.setEmployeeSalary(30000);
		session1.getTransaction().commit();
		session1.close();//same qry executed for 2 times as prev session was closed and cache got cleared
		//session is first level cache
		
		
	}
}
